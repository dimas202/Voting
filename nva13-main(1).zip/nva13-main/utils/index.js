const fullUrl = require("./fullUrl");

module.exports = { fullUrl };
