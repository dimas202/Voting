const Paslon = require("./Paslon");
const User = require("./User");

module.exports = { User, Paslon };
