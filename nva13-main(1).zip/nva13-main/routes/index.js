const notFound = require("./notFound");
const admin = require("./admin");
const main = require("./main");
const vote = require("./vote");

module.exports = { main, admin, vote, notFound };
